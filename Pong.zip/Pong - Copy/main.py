import pygame as pg, sys, random
from settings import *


def ball_animation():
    global ball_speed_x, ball_speed_y, player_score, opponent_score
    # getting the ball to move
    ball.x += ball_speed_x
    ball.y += ball_speed_y

    # getting the ball to bounce off the edges and collide with the paddles
    if ball.top <= 0 or ball.bottom >= screen_height:
        ball_speed_y *= -1
        bouncing = pg.mixer.Sound("Sound FX/Bouncing/Ping-pong-ball-bounce-sound-effect.mp3")
        pg.mixer.Sound.play(bouncing)
    if ball.right >= screen_width:
        ball_restart()
        opponent_score += 1
        edge = pg.mixer.Sound("Sound FX/Bouncing/seduction.mp3")
        pg.mixer.Sound.play(edge)
    if ball.left <= 0:
        ball_restart()
        player_score += 1
        edge = pg.mixer.Sound("Sound FX/Bouncing/seduction.mp3")
        pg.mixer.Sound.play(edge)
    if ball.colliderect(player) or ball.colliderect(opponent):
        ball_speed_x *= -1
        paddle_hits = pg.mixer.Sound("Sound FX/Bouncing/waluigi-sound.mp3")
        pg.mixer.Sound.play(paddle_hits)


def player_animation():
    player.y += player_speed
    if player.top <= 0:
        player.top = 0
    if player.bottom >= screen_height:
        player.bottom = screen_height


def opponent_animation():
    # gives opponent movement
    if opponent.top < ball.y:
        opponent.top += opponent_speed
    if opponent.bottom > ball.y:
        opponent.bottom -= opponent_speed
    if opponent.top <= 0:
        opponent.top = 0
    if opponent.bottom >= screen_height:
        opponent.bottom = screen_height


def ball_restart():
    global ball_speed_x, ball_speed_y
    # teleports the ball to the center and goes in a random direction
    ball.center = (screen_width/2, screen_height/2)
    ball_speed_y *= random.choice((1, -1))
    ball_speed_x *= random.choice((1, -1))


# Adding scores
player_score = 0
opponent_score = 0


def Win():
    global player_score
    if player_score == 3:
        win = pg.mixer.Sound("Sound FX/Win/Never Gonna Give You Up Original.mp3")
        pg.mixer.Sound.play(win)


def Game_Over():
    global opponent_score
    if opponent_score == 3:
        game_over = pg.mixer.Sound("Sound FX/Game Over/Game-over-yeah.mp3")
        pg.mixer.Sound.play(game_over)


def power_ups():
    time_stop = pg.mixer.Sound("Sound FX/Power Ups/Time Stop/Za Warudo Time Stop Sound Effect.mp3")
    power_up1 = False
    if power_up1 == True:
        pg.mixer.Sound.play(time_stop)



# General setup
pg.init()
clock = pg.time.Clock()
Win()
Game_Over()
power_ups()


# Setting up the main window
screen_width = 1050
screen_height = 480
screen = pg.display.set_mode((screen_width,screen_height))
pg.display.set_caption('Pong')


# Game Rectangles
player_image = pg.image.load('Sprites/Wah-Paddle.jpg')
ball = pg.Rect(screen_width/2 - 15, screen_height/2 - 15, 30, 30)
player = pg.Rect(1030, screen_height/2 - 70, 10, 140)
opponent = pg.Rect(10, screen_height/2 - 70, 10, 140)

# setting the balls speed
ball_speed_x = 7 * random.choice((1, -1))
ball_speed_y = 7 * random.choice((1, -1))

# setting player speed
player_speed = 0

# setting opponent speed
opponent_speed = 7


while True:
    # Handling input
    for event in pg.event.get():
        if event.type == pg.QUIT:
            pg.quit()
            sys.exit()

        # adds player movement
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_DOWN:
                player_speed += 7
            if event.key == pg.K_UP:
                player_speed -= 7
        if event.type == pg.KEYUP:
            if event.key == pg.K_DOWN:
                player_speed = 0
            if event.key == pg.K_UP:
                player_speed = 0


    # adds the movement
    ball_animation()
    player_animation()
    opponent_animation()

    # Visuals
    screen.fill(BLACK)
    pg.draw.rect(screen, WHITE, player)
    pg.draw.rect(screen, WHITE, opponent)
    pg.draw.ellipse(screen, WHITE, ball)
    pg.draw.aaline(screen, WHITE, (screen_width/2, 0), (screen_width/2, screen_height))

    # Updating the window
    pg.display.flip()
    clock.tick(60)
