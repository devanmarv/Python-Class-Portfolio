let question = {
    title: ["Who is this anime character?"],
    alternatives: ['dog', 'cat', 'bird', 'fish'],
    correctAnswer: 1
};

function start() {
    // get alternatives
    let alts = document.querySelectorAll('alternatives');
    
    alts.forEach(function(element, index){
        element.addEventListener('click', function(){
            // check correct answer
            console.log('check correct answer')
        });
    });

    // show first quetion
    showQuestion(question);
}

function showQuestion(question) {
    // show question title
    let titleDiv = document.getElementById('title');
    titleDiv.textContent = question.title;

    titleDiv.forEach(function(element, index) {
        element.textContent = question.title[index]
    });

    // show alternatives
    let alts = document.getElementById('alternatives');
    alts.textContent = question.alternatives;
    
    alts.forEach(function(element, index){
        element.textContent = question.alternatives[index];
    });
};
  
start();
