let distance = 250;
let fuel = 100;
let distancecondition = distance <= 200 && distance >= 100
let isenginefunctioning = true;

if(!isenginefunctioning || distance > 200) {
    console.log('you will make it');
}

else if(distancecondition && fuel >= 100) {
    console.log('you will make it');
}

else if(distance < 100 && fuel >= 25) {
    console.log('you will make it')
}