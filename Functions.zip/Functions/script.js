// 1 hour = 60 minutes
function hourToMinutes(hours) {
    let result = hours * 60;
    console.log(result);
    return result;
}

let a = hourToMinutes(10);
let b = hourToMinutes(20);

let dayToHours = function(days) {
    return days * 24;
}

let c = dayToHours(1);
console.log(c);

// variables declaration
let balance = 5;
let stock = 1;
let price = 5;

if(balance < price) {
    let enoughMoney = false;
    console.log('you do not have enough money')
}
if(enoughMoney = true) {
    buy = true;
}

// 1. check if we have stock
if(stock > 0) {
    console.log('There is stock');
}

else if(stock = 0) {
    sellItem(0);
    console.log('There is no more stock');
}

function sellItem(quantity) {
    // reduce stock, increase balance
    if(buy = true && price <= balance && stock >= quantity) {
        console.log(stock - quantity);
        console.log(balance - price * quantity);
    }

    else if(stock = 0) {
        console.log('There is no more of that product');
    }

    else if(quantity >= stock) {
        console.log('You ares asking for more than we have')
    }

    else if(quantity < stock) {
        console.log('You are asking for less than we have')
    }

    else if(enoughMoney = false) {
        console.log('You can not purchase this item')
    }
}

sellItem(1);