import cards

class Hand(object):
    def __init__(self):
        self.cards = []

    def add(self,card):
        self.cards.append(card)

    def give(self,other_hand,card):
        self.card.remove(card)
        other_hand.add(card)

    def clear(self):
        self.cards.clear()

    def __str__(self):
        rep = ""
        if self.cards:
            for card in self.cards:
                card.flip()
                rep += str(card)
        else:
            rep = "<EMPTY!>"

        return rep


class Deck(Hand):

    def populate(self):
        for rank in cards.Card.RANKS:
            for suit in cards.Card.SUITS:
                card = cards.Pos_Card(rank,suit)
                self.add(card)

    def deal(self,hands,per_hand = 1):
        cards_needed = len(hands) * per_hand
        if len(self.cards) >= cards_needed:
            for rounds in range(per_hand):
                for hand in hands:
                    top_card = self.cards[0]
                    self.give(hand,top_card)
        else:
            print("Out of Cards")
            for hand in hands:
                hand.clear()
            self.clear()
            self.populate()
            self.shuffel()
            self.deal(hands,per_hand)


    def shuffel(self):
        import random
        random.shuffle(self.cards)

if __name__=="__main__":
    print("this is a module not a script try running the main")
    input("\n\nPress enter key to exit.")