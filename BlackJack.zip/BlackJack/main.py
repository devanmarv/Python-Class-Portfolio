import blacJack as bj
import random
import commonGamefunctions as cgf


def main():
    print("\t\tWelcome to Blackjack!\n")
    names = []
    number = cgf.ask_number("How many players? (1-8):",low=1,high=9)
    for i in range(number):
        name = input("Enter the name of player "+str(i+1))
        names.append(name)

    game = bj.BJ_Game(names)

    again = None
    while again != "n":
        game.play()
        again = cgf.ask_yes_no("Do you ")





main()