import random


def pick_random_card(deck):
    import random
    card = random.choice(deck)
    return card

deck = ["A","K","Q","J",10,9,8,7,6,5,4,3,2]
suits = ["♡","♣","♠","♢"]
card = pick_random_card(deck)
suit = random.choice(suits)
print(card,suit)

if __name__=="__main__":
    print("this is a module not a script try running the main")
    input("\n\nPress enter key to exit.")