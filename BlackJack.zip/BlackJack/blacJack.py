import cards,hands
import commonGamefunctions as cgf
import random


class BJ_Card(cards.Pos_Card):
    ACE_VALUE = 1

    @property
    def value(self):
        if self.isfaceup:
            v = 0
        return



class BJ_Game(object):

    def __init__(self,names):
        pass

    def play(self):
        pass


card = BJ_Card("A","spades")
card.flip()
print(card.value,card.suit)