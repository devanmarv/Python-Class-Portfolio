// create a new scene
let gameScene = new Phaser.Scene('Game');

// initiate scene parameters
gameScene.init = function(){
    // player speed
    this.playerSpeed = 3;

    // enemy speed
    this.enemy1MinSpeed = 2;
    this.enemy2MinSpeed = 2;
    this.enemy3MinSpeed = 2;
    this.enemy1MaxSpeed = 4.5;
    this.enemy2MaxSpeed = 4.5;
    this.enemy3MaxSpeed = 4.5;

    // bounderies
    this.enemy1MinY = 80;
    this.enemy2MinY = 80;
    this.enemy3MinY = 80;
    this.enemy1MaxY = 280;
    this.enemy2MaxY = 280;
    this.enemy3MaxY = 280
}

// set the configuration of the game
let config = {
    type: Phaser.AUTO, // Phaser will use WebGL if avaliable,
    width: 640,
    height: 360,
    scene: gameScene
};

// create a new game, pass the configuration
let game = new Phaser.Game(config);

// Load assets
gameScene.preload = function(){
    // Load images
    this.load.image('background', 'images/assets/background.png');
    this.load.image('player', 'images/assets/player.png')
    this.load.image('enemy', 'images/assets/dragon.png')
    this.load.image('treasure', 'images/assets/treasure.png')
}

// called once after the preload ends
gameScene.create = function(){
    // create bg sprite
    // bg stands for Background
    let bg = this.add.sprite(0, 0, 'background')

    // place bachground.png in the center
    bg.setPosition(640/2, 360/2)

    // create player sprite
    let player = this.add.sprite(0, 0, 'player')

    // place player.png in the left-center of the screen
    player.setPosition(35, 180)

    // setting the scale of the player
    player.setScale(0.75);

    // create treasure sprite
    let treasure = this.add.sprite(0, 0, 'treasure')

    // place treasure.png in te right-center of the screen
    treasure.setPosition(565, 180)

    // setting the scale of the treasure
    treasure.setScale(0.75);

    // create enemy sprites
    let enemy1 = this.add.sprite(0, 0, 'enemy')
    let enemy2 = this.add.sprite(0, 0, 'enemy')
    let enemy3 = this.add.sprite(0, 0, 'enemy')

    // flips the enemies
    this.enemy.flipX = true;

    // setting the scale of the enemies
    enemy1.setScale(0.75);
    enemy2.setScale(0.75);
    enemy3.setScale(0.75);

    // place dragon.png's on the screen
    enemy1.setPosition(160, 90)
    enemy2.setPosition(320, 90)
    enemy3.setPosition(480, 90)

    // sets the enemy to rotate
    this.enemy2.rotation = Math.PI / 4;
    this.enemy1.rotation = Math.PI / 4;
    this.enemy3.rotation = Math.PI / 4;

    this.enemy1.setRotation(Math.PI /4);
    this.enemy1.setRotation(Math.PI /4);
    this.enemy1.setRotation(Math.PI /4);

    // set enemy speed
    let dir

    console.log(this.enemy1);
    console.log(this.enemy2);
    console.log(this.enemy3);
}

// this is called up 60 times per second
gameScene.update = function(){
    this.enemy1.x += 1;
    this.enemy2.x += 1;
    this.enemy3.x += 1;

    this.enemy1.angle += 1;
    this.enemy2.angle += 1;
    this.enemy3.angle += 1;

    // check if we've reached scale of 2
    if(this.player.scaleX < 2) {

        // make the player grow
        this.player.scaleX += 0.01;
        this.player.scaleY += 0.01;
    }

    if(this.input.activePointer.isDown) {
        // player walks
        this.player.x += this.playerSpeed;
    }

    // treasure overlap
    let playerRect = this.player.getBounds();
    let treasureRect = this.treasure.getBounds();

    if(Phaser.Geom.Intersects.RectangleToRectangle(playerRect, treasureRect)) {
        console.log('Reached Goal!')

        // restarts the Scene
        this.scene.restart();

        // make sure we leave this meatod
        return;
    }
};